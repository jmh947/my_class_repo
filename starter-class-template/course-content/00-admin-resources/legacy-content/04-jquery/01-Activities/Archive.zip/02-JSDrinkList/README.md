### File

* [`drinklist-unsolved`](Unsolved/drinklist-unsolved.html)

### Instructions

* Using the file above as a starting point, add the missing code such that your JavaScript generates HTML content that displays all of the drink options.

* **HINT:**  You will need a for-loop. Inside your for-loop you will need to use each of the following methods/properties: `.createElement`, `.textContent`, and `.appendChild`.

* **BONUS:** Instead of using a `for` loop, use the `.forEach` method.
